<?php if ( opt('vertical_template') == 0 ) { ?>
	
			<!-- last white part -->
		<div class="cvpage first-block" ></div>
	</div>
	
<?php } else if  ( opt('vertical_template') == 1 ) {  ?>

			</div>
		</div>
	</div>
	
<?php }
	