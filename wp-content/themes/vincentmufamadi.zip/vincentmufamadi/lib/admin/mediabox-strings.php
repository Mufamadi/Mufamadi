<?php
function Get_MediaBox_Strings()
{
	return array(
	
		'px-portfolio-image' => __('Insert Image', TEXTDOMAIN ),
		'px-settings-logo' => __('Insert Logo', TEXTDOMAIN ),
		'px-settings-favicon' => __('Insert Favicon', TEXTDOMAIN ),
		'px-settings-banner' => __('Insert Banner', TEXTDOMAIN ),
		'px-settings-about-photo' => __('Insert photo', TEXTDOMAIN ),
		'px-settings-about-signature' => __('Insert signature', TEXTDOMAIN ),
		'px-settings-work-Experience-image' => __('Insert work experience image', TEXTDOMAIN ),
		'px-settings-loginlogo' => __('Insert login logo', TEXTDOMAIN ),
		'px-settings' => __('Insert', TEXTDOMAIN ),
		
		);
}
?>